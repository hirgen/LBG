package net.ccbluex.liquidbounce.injection.implementations;

/**
 * LiquidBounce Hacked Client
 * A minecraft forge injection client using Mixin
 *
 * @game Minecraft
 * @author CCBlueX
 */
public interface IItemStack {
    long getItemDelay();
}