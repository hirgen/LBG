package net.ccbluex.liquidbounce.utils;

import net.minecraft.client.Minecraft;

public class MinecraftInstance {
    protected static final Minecraft mc = Minecraft.getMinecraft();
}
