package net.ccbluex.liquidbounce.chat.packet.packets

/**
 * A axochat packet
 */
interface Packet