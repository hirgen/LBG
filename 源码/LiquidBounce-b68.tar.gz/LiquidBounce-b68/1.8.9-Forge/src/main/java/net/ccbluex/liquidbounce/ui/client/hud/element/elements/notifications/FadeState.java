package net.ccbluex.liquidbounce.ui.client.hud.element.elements.notifications;

/**
 * LiquidBounce Hacked Client
 * A minecraft forge injection client using Mixin
 *
 * @game Minecraft
 * @author CCBlueX
 */
public enum FadeState {
    IN, STAY, OUT, END
}
